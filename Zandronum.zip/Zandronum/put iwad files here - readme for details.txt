doom.wad
doom2.wad
tnt.wad
plutonia.wad